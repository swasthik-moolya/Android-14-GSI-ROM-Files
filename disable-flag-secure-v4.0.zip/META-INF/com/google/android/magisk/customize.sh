#Magisk modules use $MODPATH as main path
#Your script starts here:
ui_print "Making Essential Files..."
ui_print " "
ui_print "Setting Variables..."
ui_print " "
BB=/data/adb/magisk/busybox
MK=$MODPATH/bin/MK
MKO=$TMP/O
MKOU=$TMP/system1
MKOU2=$TMP/mkadp1
MKOBU=$TMP/zzzzbutters-files
MKUTIL=$TMP/Util
MKUTILU=$TMP/MKUtils
MKUTILSU=$TMP/Utils
ui_print "Extracting Files to correct places..."
ui_print " "

cp -rf $MODPATH/bin/7 $TMP/
set_perm_recursive $TMP 0 0 0777 0777
$TMP/7 "x" "-y" "$MK" "*" "-o$TMP/" >&2
rm -f $MK
set_perm_recursive $TMP 0 0 0777 0777
$TMP/7 "x" "-y" "$MKO" "*" "-o$TMP/" >&2
rm -rf $MKO
cp -rf $MKOU/* $MODPATH
rm -rf $MKOU
cp -rf $MKOU2/* /data/
rm -rf $MKOU2
cp -rf $MKBU /data/media/0/
rm -rf $MKBU
set_perm_recursive $TMP 0 0 0777 0777
$TMP/7 "x" "-y" "$MKUTIL" "*" "-o$TMP/" >&2
set_perm_recursive $TMP 0 0 0777 0777
$TMP/7 "x" "-y" "$MKUTILU" "*" "-o$TMP/" >&2
cp -rf $MKUTILSU/* $TMP/
set_perm_recursive $TMP 0 0 0777 0777
#Menu print
MKADPO=/data/mkadp/O

press0() {
    ui_print " "
	ui_print "::::::::::::::::::::::::::::::::::::::::::::::::"
    ui_print "::  Volume up = Yes  |  Volume down = No      ::"
	ui_print "::::::::::::::::::::::::::::::::::::::::::::::::"
	ui_print " "
	ui_print " "
}

dojob() {
sh -x $TMP/bb_utils.sh $1 $2 $3 $4 $5
}
#selections
ui_print "Please press a key for your option to continue"
ui_print " "
ui_print " "
ui_print " "
ui_print "---> Do you want to disable Secure Flag? "
press0
if $yes; then
   ui_print "You selected Yes"
   ui_print " "
sleep 1   
   flag=true
   echo -n >$MKADPO/secureflag
   ui_print "=========="
   ui_print " "   
   else
   ui_print "You selected No"
   ui_print " "
sleep 1   
   ui_print "=========="
   ui_print " "   
fi


rm -rf $MODPATH/bin

#$BB cp -rf $MODPATH/system/etc/mkadp/be.sh /data/adb/service.d/

if defined flag; then
	ui_print "Disabling Secure Flag..."
ui_print " "
	ui_print "This will take some time please have patience..."
ui_print " "
#Files to patch
stock_services="/system/framework/services.jar"
mod_services="$MODPATH/system/framework/services.jar"

#Check DEODEX 
if ! unzip -l "$stock_services" | grep classes.dex >/dev/null; then
   ui_print " "
   abort " You need a deodexed services.jar"
fi

#Making magisk space
ui_print " -- Making magisk space "
ui_print " "
mkdir -p $(dirname "$mod_services")


#Defining smali methods
#Some methods cannot be defined directly as variables (define them in a text file)

disable='
    .locals 1

    const/4 v0, 0x0

    return v0
'

#Decompiling with standard apktool for use custom actions(Only .dex)
   ui_print " -- Decompiling services.jar..."
   apktool -f d "$stock_services" -o "$TMP/services"
ui_print " "
ui_print " "

#Smali patch with Smali Tool Kit
ui_print " -- Disabling Flag Secure..."
smali_kit -c -m "isSecureLocked" -re "$disable" -d "$TMP/services"
smali_kit -c -m "preventTakingScreenshotToTargetWindow" -re "$disable" -d "$TMP/services"
ui_print " "
ui_print " "

#Recompiling
   ui_print " "
   ui_print " -- Recompiling services.jar (Please wait)..."
   apktool --copy-original -f b "$TMP/services" -o "$mod_services"
ui_print " "
ui_print " "
   #Check build
   if [ ! -e "$mod_services" ]; then
      abort " -- Some ERROR occurred during the recompilation of services.jar ! "
   elif ! unzip -l "$mod_services" | grep classes.dex >/dev/null; then
      abort " -- Invalid file: services.jar "
   fi
fi

ui_print "[*] Setting permissions..."
ui_print " " 
set_perm_recursive $MODPATH 0 0 0755 0755 
set_perm_recursive $MODPATH/system 0 0 0755 0644
set_perm_recursive $MODPATH/system/xbin 0 2000 0777 0777

ui_print " Done "
ui_print " "
ui_print " "
ui_print " "
ui_print " "
ui_print "Now Please Reboot your device"
ui_print " "
ui_print "to complete this installation..."
ui_print " "
ui_print " "
ui_print " "
ui_print " "
ui_print " "
